USE Biblioteka
CREATE TABLE KSIAZKI (
IdKsiazki int(20) NOT NULL,
imie_autora varchar(50) NOT NULL,
nazwisko_autora varchar(50) NOT NULL,
 wydawnictwo varchar(10) NOT NULL
PRIMARY KEY (idPracownika)
);

INSERT INTO Ksiażki
VALUES ('1','Wiedzmin','Andrzej','Sapkowski');
INSERT INTO Ksiażki
VALUES ('2','Hary Potter','J.K','Rowling');
INSERT INTO Ksiażki
VALUES ('3','Zemsta','Aleksander','Fredro');