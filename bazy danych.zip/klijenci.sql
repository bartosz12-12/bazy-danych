USE Biblioteka
CREATE TABLE Klijenci (
IdKlijenta int(20) NOT NULL,
imie varchar(50) NOT NULL,
nazwisko varchar(50) NOT NULL,
 nr_tel varchar(10) NOT NULL
PRIMARY KEY (idPracownika)
);
INSERT INTO Klijenci
VALUES ('2','Bartosz','Mały','Biała Piska','234568936');
INSERT INTO Klijenci
VALUES ('3','Michał','Mały','Biała Piska','256468936');
INSERT INTO Klijenci
VALUES ('6','Bartosz','Kanapa','Pisz','875460967');