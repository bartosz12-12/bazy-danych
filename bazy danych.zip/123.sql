SELECT * FROM Hurtownia
WHERE kwota >2000

SELECT * FROM Pracownicy
WHERE Imie = 'Barbara' AND Nazwisko = 'Czekaj'

SELECT * FROM Pracownicy
WHERE Imie = 'Barbara' OR NOT Nazwisko = 'Czekaj'

UPDATE Hurtownia
SET kwota=kwota+100

SELECT MIN(kwota),MAX(kwota)FROM Hurtownia

SELECT*
FROM Klijenci, Ksiażki

SELECT Pracownicy.Imie, Klijenci.Nazwisko FROM Pracownicy JOIN Klijenci 

SELECT
