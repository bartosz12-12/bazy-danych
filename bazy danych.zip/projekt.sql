CREATE DATABASE Biblioteka
USE Biblioteka
CREATE TABLE Biblioteka (
IdBiblioteka int(20) NOT NULL,
liczba_pracownikow int(20) NOT NULL,
adres varchar(10) NOT NULL
PRIMARY KEY (idBiblioteka)
);
INSERT INTO Biblioteka
VALUES ('1','6','Biała Piska', NULL);
SELECT *
FROM Biblioteka;