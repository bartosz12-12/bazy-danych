USE biblioteka;
CREATE TABLE IF NOT EXISTS `biblioteka`.`Biblioteka` (
`idBiblioteki` INT NOT NULL AUTO_INCREMENT COMMENT 'Klucz główny',
`Adres` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Adres',
`godziny otwarcia` VARCHAR(45) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Godziny',
`kod_pocztowy` VARCHAR(45) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Kod pocztowy',
`email` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Adres e-mail',
PRIMARY KEY (`idBiblioteki`));
CREATE TABLE IF NOT EXISTS `biblioteka`.`ksiazki` (
`id_ksiazka` INT NOT NULL AUTO_INCREMENT COMMENT 'Id ksiazki',
`tytul` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Tytuł książki',
`Imie autora` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Imie autora',
`Nazwisko autora` VARCHAR(70) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Imię i Nazwisko autora książki',
`stron` INT(4) NOT NULL COMMENT 'Liczba stron książki',
`wydawnictwo` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Nazwa wydawnictwa, w którym wydano książkę',
PRIMARY KEY (`id_ksiazka`));
CREATE TABLE IF NOT EXISTS `biblioteka`.`Pracownicy` (
`idPracownika` INT NOT NULL AUTO_INCREMENT COMMENT 'Id pracownika',
`Imie` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Imie',
`Nazwisko` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Nazwisko',
`Pesel` INT(4) NOT NULL COMMENT 'Adres',
`Data ur` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Data ur', 
PRIMARY KEY (`id_ksiazka`));
CREATE TABLE IF NOT EXISTS `biblioteka`.`klijent` (
`idKlijenta` INT NOT NULL AUTO_INCREMENT COMMENT 'Id klijenta',
`imie` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Imię ',
`nazwisko` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Nazwisko',
`adres` VARCHAR(200) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Adres zamieszkania',
`telefon` VARCHAR(50) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NULL COMMENT 'Telefony',
`kod_pocztowy` VARCHAR(45) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Kod pocztowy',
`email` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_polish_ci' NOT NULL COMMENT 'Adres e-mail',
PRIMARY KEY (`id_czytelnik`));
INSERT INTO Klijenci
VALUES ('2','Bartosz','Mały','Biała Piska','234568936','12-230');
INSERT INTO Klijenci
VALUES ('3','Michał','Mały','Biała Piska','256468936''12-230');
INSERT INTO Klijenci
VALUES ('6','Bartosz','Kanapa','Pisz','875460967''12-220');
INSERT INTO Ksiażki
VALUES ('1','Wiedzmin','Andrzej','Sapkowski','300');
INSERT INTO Ksiażki
VALUES ('2','Hary Potter','J.K','Rowling','100');
INSERT INTO Ksiażki
VALUES ('3','Zemsta','Aleksander','Fredro','200');
INSERT INTO Pracownicy
VALUES ('3','Barbara','Siok','898779889','15.12.1996',NULL);
INSERT INTO Pracownicy
VALUES ('1','Barbara','Czekaj','898776549','07.08.2001',NULL);
INSERT INTO Pracownicy
VALUES ('2','Katarzyna','Czekaj','123456789','07.08.1998',NULL);
INSERT INTO Biblioteka
VALUES ('1','Biała Piska','8-17','12-230','hhkhfk@iijj.pl');
INSERT INTO Biblioteka
VALUES ('3','Pisz','8-17','12-220','hhkhfk@iijj.pl');
