USE Biblioteka
CREATE TABLE Pracownicy (
IdPracownika int(20) NOT NULL,
imie varchar(50) NOT NULL,
nazwisko varchar(50) NOT NULL,
adres varchar(10) NOT NULL
PRIMARY KEY (idPracownika)
);
INSERT INTO Pracownicy
VALUES ('3','Barbara','Siok','898779889','15.12.1996',NULL);
INSERT INTO Pracownicy
VALUES ('1','Barbara','Czekaj','898776549','07.08.2001',NULL);
INSERT INTO Pracownicy
VALUES ('2','Katarzyna','Czekaj','123456789','07.08.1998'NULL);