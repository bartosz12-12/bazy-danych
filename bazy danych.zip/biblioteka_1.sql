INSERT INTO Pracownicy
VALUES ('1','Barbara','Czekaj','898776549','07.08.2001');
INSERT INTO Pracownicy
VALUES ('2','Katarzyna','Czekaj','123456789','07.08.1998');
INSERT INTO Pracownicy
VALUES ('3','Barbara','Siok','898779889','15.12.1996');
INSERT INTO Ksiażki
VALUES ('1','Wiedzmin','Andrzej','Sapkowski');
INSERT INTO Ksiażki
VALUES ('2','Hary Potter','J.K','Rowling');
INSERT INTO Ksiażki
VALUES ('3','Zemsta','Aleksander','Fredro');
INSERT INTO Hurtownia
VALUES ('1','Wiedzmin','200','4000');
INSERT INTO Hurtownia
VALUES ('1','Zemsta','390','6000');
INSERT INTO Hurtownia
VALUES ('1','Krzyzacy','170','2900');
INSERT INTO Klijenci
VALUES ('2','Bartosz','Mały','Biała Piska','234568936');
INSERT INTO Klijenci
VALUES ('3','Michał','Mały','Biała Piska','256468936');
INSERT INTO Klijenci
VALUES ('6','Bartosz','Kanapa','Pisz','875460967');
INSERT INTO Biblioteka
VALUES ('1','6','Biała Piska');