USE Biblioteka
CREATE TABLE Hurtownia (
IdHurtownia int(20) NOT NULL,
tytul varchar(50) NOT NULL,
ilosc int(10) NOT NULL,
 nr_tel varchar(10) NOT NULL
PRIMARY KEY (idPracownika)
